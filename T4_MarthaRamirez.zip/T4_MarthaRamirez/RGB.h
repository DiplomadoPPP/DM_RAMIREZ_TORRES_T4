#ifndef RGB_H_
#define RGB_H_

void set_RGB_off	();
void set_RGB_yellow ();
void set_RGB_red	();
void set_RGB_purple	();
void set_RGB_blue	();
void set_RGB_green	();
void set_RGB_white	();

#endif /* GPIO_H_ */